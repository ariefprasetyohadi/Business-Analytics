# Marketing-Analytics
Sebuah projek data analysis yang berfokus untuk menganalisa hal yang berkaitan dengan marketing. 
